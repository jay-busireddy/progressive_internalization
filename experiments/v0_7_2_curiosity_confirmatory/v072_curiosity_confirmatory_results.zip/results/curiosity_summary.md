# v0.7.2.2 Synthetic Curiosity Summary

Rows analyzed: 192

- **gap_curiosity**: score 1.000, gap 1.000, select-recall 1.000, supported-bridge 1.000, eligible 3.00, pursued 3.00, prompt 407.2, query 13.7s, idle/ingest 0.0s
- **generic_seek**: score 0.639, gap 1.000, select-recall 0.639, supported-bridge 0.639, eligible 3.00, pursued 1.92, prompt 1642.7, query 13.0s, idle/ingest 27.3s
- **no_memory**: score 0.000, gap 1.000, select-recall 0.000, supported-bridge 0.000, eligible 3.00, pursued 0.00, prompt 220.8, query 10.3s, idle/ingest 0.0s
- **no_seek**: score 0.000, gap 1.000, select-recall 0.000, supported-bridge 0.000, eligible 3.00, pursued 0.00, prompt 326.4, query 13.8s, idle/ingest 0.0s
- **oracle_relevant**: score 0.931, gap 1.000, select-recall 0.000, supported-bridge 0.000, eligible 3.00, pursued 0.00, prompt 673.9, query 19.6s, idle/ingest 0.0s
- **oracle_seek_consolidated**: score 0.958, gap 1.000, select-recall 1.000, supported-bridge 1.000, eligible 3.00, pursued 3.00, prompt 407.2, query 7.7s, idle/ingest 0.0s
- **oracle_seek_direct**: score 0.972, gap 1.000, select-recall 1.000, supported-bridge 0.000, eligible 3.00, pursued 3.00, prompt 802.9, query 22.4s, idle/ingest 0.0s
- **random_seek**: score 0.097, gap 1.000, select-recall 0.125, supported-bridge 0.125, eligible 3.00, pursued 3.00, prompt 336.5, query 8.0s, idle/ingest 0.0s

Validity: no_memory=0.000; oracle_relevant=0.931; oracle_seek_direct=0.972; oracle_seek_consolidated=0.958.
Gap-curiosity detection=1.000; selection recall=1.000; supported post-learning bridge=1.000.
Gap - Random: delta +0.903, wins/ties/losses=24/0/0
Gap - Generic: delta +0.361, wins/ties/losses=24/0/0
Gap - NoSeek: delta +1.000, wins/ties/losses=24/0/0

**Verdict:** POSITIVE SYNTHETIC CURIOSITY MECHANISM; GAP-DRIVEN ALSO BEATS GENERIC SEEKING.

## Per-world scores
| scenario_id   |   seed |   gap_curiosity |   generic_seek |   no_memory |   no_seek |   oracle_relevant |   oracle_seek_consolidated |   oracle_seek_direct |   random_seek |
|:--------------|-------:|----------------:|---------------:|------------:|----------:|------------------:|---------------------------:|---------------------:|--------------:|
| syn01         |      0 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0        |
| syn01         |      1 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0        |
| syn02         |      0 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0        |
| syn02         |      1 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0        |
| syn03         |      0 |               1 |       0        |           0 |         0 |          1        |                          1 |             1        |      0        |
| syn03         |      1 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0        |
| syn04         |      0 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0        |
| syn04         |      1 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0.333333 |
| syn05         |      0 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0        |
| syn05         |      1 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0        |
| syn06         |      0 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0.666667 |
| syn06         |      1 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0        |
| syn07         |      0 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0        |
| syn07         |      1 |               1 |       0.666667 |           0 |         0 |          0.333333 |                          1 |             1        |      0        |
| syn08         |      0 |               1 |       0.666667 |           0 |         0 |          1        |                          0 |             1        |      0        |
| syn08         |      1 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0.333333 |
| syn09         |      0 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0.333333 |
| syn09         |      1 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0.333333 |
| syn10         |      0 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             0.333333 |      0        |
| syn10         |      1 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0        |
| syn11         |      0 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0        |
| syn11         |      1 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0        |
| syn12         |      0 |               1 |       0.666667 |           0 |         0 |          1        |                          1 |             1        |      0        |
| syn12         |      1 |               1 |       0.666667 |           0 |         0 |          0        |                          1 |             1        |      0.333333 |